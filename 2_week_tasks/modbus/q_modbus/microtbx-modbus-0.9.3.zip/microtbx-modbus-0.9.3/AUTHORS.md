# Authors of MicroTBX-Modbus

* Frank Voorburg designed and implemented the initial version of MicroTBX-Modbus.
